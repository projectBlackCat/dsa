/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsa;

import java.util.Arrays;

/**
 *
 * @author rajak
 */
public class Merge {
    
    public static int[] merger(int[] array1, int[] array2){
        int array1len = array1.length;
            int array2len = array2.length;         
            int[] arrayNew = new int[array1len+array2len];
        for(int i=0;i<array1.length;i++){
            arrayNew[i] = array1[i];
        }
        for(int i=0;i<array2.length;i++){
            arrayNew[i+array1len] = array2[i];
        }
        return arrayNew;
    }
    
    
    public static void main(String[] args) {
        
        int[] arr1 = {1,2,3,4,5,6};
        int[] arr2 = {7,8,9,10,11,12};
        
        int[] end = merger(arr1, arr2);
        
        System.out.println(Arrays.toString(end)); 
        
        
        
    }
    
}
