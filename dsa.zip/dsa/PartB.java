package dsa;

import java.util.LinkedList;

/**
 *
 * @author rajak
 */
public class PartB {
    private LinkedList<Integer> queue = new LinkedList<>(); // Using Integer for type safety
    public void enqueue(int data) {
        queue.addLast(data); // Add to the end of the queue
    }

    public void dequeue() {
        if (!queue.isEmpty()) { // Check if the queue is not empty
            queue.removeFirst(); // Remove from the front of the queue
        } else {
            System.out.println("Queue is empty. Cannot dequeue.");
        }
    }

    // Show method to display the current state of the queue
    public void show() {
        System.out.println(queue);
    }

    // Main method to test the queue operations
    public static void main(String[] args) {
        PartB saaru = new PartB();
        saaru.enqueue(1); // Changed to integer
        saaru.enqueue(2);
      
        System.out.println("Queue after enqueuing 1, 2, 3:");
        saaru.show(); // Output: [1, 2, 3]

        saaru.dequeue(); // Removes 1
        System.out.println("Queue after dequeuing:");
        saaru.show(); // Output: [2, 3]
    }
}
