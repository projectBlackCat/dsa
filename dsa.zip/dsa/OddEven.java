/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsa;

import java.util.Arrays;
import java.util.LinkedList;

/**
 *
 * @author rajak
 */
public class OddEven {
    
    
    
   
    public static void oddeven(int[] arr){
        int even=0;
        int odd =0;
        for(int i=0; i<arr.length;i++){
            if(arr[i]%2==0){
                even = even+1;
            }
            else{
                odd = odd+1;
            }
        }
        int[] evenArr = new int[even];
        int[] oddArr = new int[odd];
        
        int x=0;
        int y=0;
        for(int i=0; i<arr.length;i++){
            if(arr[i]%2==0){
                evenArr[x++] = arr[i];
                
            }
            else{
                oddArr[y++] = arr[i];
            }
        }
        
        System.out.println("Even Array is: " + Arrays.toString(evenArr));
        System.out.println("Odd Array is: " + Arrays.toString(oddArr));
    }
    
    public static void main(String[] args) {
        
        
        int[] arr ={5,6,4,7,8,7};
        
        oddeven(arr);
    }
    
}
