/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsa;

/**
 *
 * @author rajak
 */
public class LinkedListExample {

    // Node class representing each element in the linked list
    static class Node {
        int data;
        Node nextNode;

        Node(int data) {
            this.data = data;
            this.nextNode = null;
        }
    }

    // LinkedList class
    static class LinkedList {
        Node head; // first node

        // Method to insert an element at the end of the list
        public void insert(int data) {
            Node node = new Node(data); // CREATE AN OBJECT
            if (head == null) {
                head = node;
            } else {
                Node n = head;
                while (n.nextNode != null) {
                    n = n.nextNode;
                }
                n.nextNode = node;
            }
        }

        // Method to insert an element at the beginning of the list
        public void insertAtFirst(int data) {
            Node node = new Node(data);
            node.nextNode = head;
            head = node;
        }

        // Method to insert an element at a specific position
        public void insertAt(int index, int data) {
            if (index == 0) {
                insertAtFirst(data);
            } else {
                Node node = new Node(data);
                Node n = head;
                for (int i = 0; i < index - 1; i++) {
                    if (n != null) {
                        n = n.nextNode;
                    } else {
                        throw new IndexOutOfBoundsException("Index out of bounds");
                    }
                }
                node.nextNode = n.nextNode;
                n.nextNode = node;
            }
        }

        // Method to delete an element at a specific position
        public void deleteAt(int index) {
            if (head == null) {
                throw new IndexOutOfBoundsException("Index out of bounds");
            }
            if (index == 0) {
                head = head.nextNode;
            } else {
                Node n = head;
                Node prev = null;
                for (int i = 0; i < index; i++) {
                    if (n != null) {
                        prev = n;
                        n = n.nextNode;
                    } else {
                        throw new IndexOutOfBoundsException("Index out of bounds");
                    }
                }
                if (n != null) {
                    prev.nextNode = n.nextNode;
                } else {
                    throw new IndexOutOfBoundsException("Index out of bounds");
                }
            }
        }

        // Method to display the elements of the list
        public void show() {
            Node node = head;
            while (node != null) {
                System.out.print(node.data + " ");
                node = node.nextNode; // shift to the next node
            }
            System.out.println();
        }

        // Main method to demonstrate the functionality
        public static void main(String[] args) {
            LinkedList list = new LinkedList();
            list.insert(10);
            list.insert(20);
            list.insert(30);
            list.show(); // Output: 10 20 30

            list.insertAtFirst(5);
            list.show(); // Output: 5 10 20 30

            list.insertAt(2, 15);
            list.show(); // Output: 5 10 15 20 30

            list.deleteAt(3);
            list.show(); // Output: 5 10 15 30
        }
    }
}

