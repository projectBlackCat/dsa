/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsa;

/**
 *
 * @author rajak
 */
import java.util.Stack;

public class BalancedParentheses {

    // Method to check if the given string has balanced parentheses
    public static boolean isBalanced(String expression) {
        Stack<Character> stack = new Stack<>();

        for (char ch : expression.toCharArray()) {
            // If the character is an opening parenthesis, push it onto the stack
            if (ch == '(' || ch == '{' || ch == '[') {
                stack.push(ch);
            } 
            // If the character is a closing parenthesis
            else if (ch == ')' || ch == '}' || ch == ']') {
                // If the stack is empty, return false
                if (stack.isEmpty()) {
                    return false;
                }

                // Pop the top element from the stack
                char top = stack.pop();

                // Check if the popped element matches the current closing parenthesis
                if ((ch == ')' && top != '(') || 
                    (ch == '}' && top != '{') || 
                    (ch == ']' && top != '[')) {
                    return false;
                }
            }
        }

        // If the stack is empty, all parentheses were balanced
        return stack.isEmpty();
    }

    // Main method to test the isBalanced method
    public static void main(String[] args) {
        String expression1 = "{[()]}";
        String expression2 = "{[(])}";
        String expression3 = "{{[[(())]]}}";

        System.out.println("Expression: " + expression1 + " is balanced: " + isBalanced(expression1));
        System.out.println("Expression: " + expression2 + " is balanced: " + isBalanced(expression2));
        System.out.println("Expression: " + expression3 + " is balanced: " + isBalanced(expression3));
    }
}

