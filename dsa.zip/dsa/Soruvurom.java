/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsa;

import java.util.Arrays;

/**
 *
 * @author rajak
 */
public class Soruvurom {
    
    public static char[]  soruval(char[] arrayA, char[] arrayB){
        char[] end = new char[8];
        int j = 0;
        for(int i=0; i<4;i++){
            end[j]=arrayA[i];
            j+=2;
        
        }
        int k=1;
         for(int i=0; i<4;i++){
            end[k] = arrayB[i];
            k+=2;
        
        }
    return end;
    }
    
    
    
    public static void main(String[] args) {
        char[] arr1 = {'a','b','c','d'};
        char[] arr2 = {'e','f','g','h'};
        
        System.out.println(Arrays.toString(soruval(arr1, arr2)));
    }
}
