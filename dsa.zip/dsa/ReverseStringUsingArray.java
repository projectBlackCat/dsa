/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsa;

/**
 *
 * @author rajak
 */
public class ReverseStringUsingArray {

    // Method to reverse a string using an array
    public static String reverseString(String input) {
        int length = input.length();
        char[] stack = new char[length]; // Array to simulate stack
        int top = -1; // Stack pointer

        // Push each character of the string onto the array
        for (int i = 0; i < length; i++) {
            stack[++top] = input.charAt(i);
        }

        StringBuilder reversedString = new StringBuilder();

        // Pop each character from the array to form the reversed string
        while (top >= 0) {
            reversedString.append(stack[top--]);
        }

        return reversedString.toString();
    }

    // Main method to test the reverseString method
    public static void main(String[] args) {
        String originalString = "Hello, World!";
        System.out.println("Original String: " + originalString);
        
        String reversedString = reverseString(originalString);
        System.out.println("Reversed String: " + reversedString);
    }
}

