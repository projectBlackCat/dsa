/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsa;

/**
 *
 * @author rajak
 */
public class L2s {


    public static void main(String[] args) {
        int[] array = {5, 1, 9, 3, 7, 6, 8, 2, 4};
        System.out.println("Original array:");
        printArray(array);

        interchangeLargestSmallest(array);

        System.out.println("Array after interchanging largest and smallest elements:");
        printArray(array);
    }

    public static void interchangeLargestSmallest(int[] array) {
        if (array == null || array.length < 2) {
            return; // No need to process if array is null or has less than 2 elements
        }

        int maxIndex = 0;
        int minIndex = 0;

        // Find the indices of the largest and smallest elements
        for (int i = 1; i < array.length; i++) {
            if (array[i] > array[maxIndex]) {
                maxIndex = i;
            } else if (array[i] < array[minIndex]) {
                minIndex = i;
            }
        }

        // Swap the largest and smallest elements
        int temp = array[maxIndex];
        array[maxIndex] = array[minIndex];
        array[minIndex] = temp;
    }

    public static void printArray(int[] array) {
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }


}
