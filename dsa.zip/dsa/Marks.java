import java.util.Arrays;

public class Marks {

    public static void main(String[] args) {
        int[] marks = {78, 56, 78, 98, 78, 98, 80, 79};
        int newMark = 67;
        
        // Append the new mark at the end of the array
        marks = appendMark(marks, newMark);
        System.out.println("Array after appending new mark:");
        System.out.println(Arrays.toString(marks));

        // Insert the new mark at the 3rd position (index 2)
        marks = insertMarkAtPosition(marks, newMark, 2);
        System.out.println("Array after inserting new mark at 3rd position:");
        System.out.println(Arrays.toString(marks));
    }

    public static int[] appendMark(int[] array, int mark) {
        int[] newArray = Arrays.copyOf(array, array.length + 1);
        newArray[array.length] = mark;
        return newArray;
    }

    public static int[] insertMarkAtPosition(int[] array, int mark, int position) {
        if (position < 0 || position > array.length) {
            throw new IllegalArgumentException("Invalid position");
        }
        
        int[] newArray = new int[array.length + 1];
        for (int i = 0, j = 0; i < newArray.length; i++) {
            if (i == position) {
                newArray[i] = mark;
            } else {
                newArray[i] = array[j++];
            }
        }
        return newArray;
    }
}
