/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsa;

/*
 *
 * @author rajak
 */
public class BubbleSort {
    public static void bubbleSort(int[] array) {
    int n = array.length;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - 1 - i; j++) {
            if (array[j] > array[j + 1]) {
                int temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
            }
        }
    }
}
    
    public static void main(String[] args) {
        int[] array1 = {1,2,5,4,7};
        BubbleSort bs = new BubbleSort();
        bs.bubbleSort(array1);
        System.out.println(array1);
       
    }
    

}

