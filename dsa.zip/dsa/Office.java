/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsa;

import java.util.Arrays;

/**
 *
 * @author rajak
 */
public class Office {

    

    public static int[] rmv(int[] arr, int val) { //remove one element from the array
        int pos = 0;
        for (int i = 0; i < arr.length; i++) {
            if(arr[i]==val){
                pos = i;
            }
        }
        int[] newArray = new int[arr.length-1];
        
        int k=0;
        for(int j=0;j<arr.length;j++){
                if(pos==j){
                    continue;
                }
                else{
                    newArray[k]= arr[j];
                    k++;
                }
        }
        
 return newArray;
    }
    
    public static void main(String[] args) {
        int[] eid = {1001, 1003, 1004, 1005, 1007, 1009, 1014, 1021};
        
        System.out.println(Arrays.toString(rmv(eid, 1005)));
    }

}
