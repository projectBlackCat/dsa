/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsa;

/**
 *
 * @author rajak
 */
class Queue{
    int a[] = new int[5];
    int f = -1;
    int r = -1;

public void enqueue(int data){
        if(r==4){
            System.out.println("Queue overflow");
        }
        else if( f==-1&& r==-1){
            a[0]= data;
            r++;
            f++;
           
        }
        else{
            a[++r]= data;
        }

}

public void dequeue(){
        if(f==-1 && r==-1){
            System.out.println("Stack is empty");
        }
        else if(r==f){
            f= -1;
            r= -1;
            
        }
        else{
            f++;
            System.out.println(a[f]);
        }

}
public void display(){
        if(f==-1 && r ==-1){
            System.out.println("Queue is empty");
        }
        else{
            for(int i=f; i<=r;i++){
                System.out.println(a[i]);
            }
            
        }
        
        

}


}